// Document ready function with GSAP animations
document.addEventListener('DOMContentLoaded', function() {
    // Add fade-in animation to all pages
    gsap.from("main", { duration: 0.5, opacity: 0, y: 20, ease: "power2.out" });
    
    // Add hover effects to all buttons
    const buttons = document.querySelectorAll('button, .btn, [role="button"]');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            gsap.to(button, { 
                scale: 1.05, 
                duration: 0.2,
                ease: "power2.out"
            });
        });
        button.addEventListener('mouseleave', () => {
            gsap.to(button, { 
                scale: 1, 
                duration: 0.2,
                ease: "power2.out"
            });
        });
    });
    
    // Form validation for file uploads with animation
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', () => {
            const file = input.files[0];
            if (file) {
                const fileSize = file.size / 1024 / 1024; // in MB
                const maxSize = input.accept.includes('image') ? 2 : 16; // 2MB for images, 16MB for others
                
                if (fileSize > maxSize) {
                    // Create and animate error message
                    const errorMsg = document.createElement('div');
                    errorMsg.className = 'mt-2 text-sm text-red-600 animate-fade-in';
                    errorMsg.innerHTML = `<i class="fas fa-exclamation-circle mr-1"></i> File size should not exceed ${maxSize}MB`;
                    
                    // Remove any existing error message
                    const existingError = input.nextElementSibling;
                    if (existingError && existingError.className.includes('text-red-600')) {
                        existingError.remove();
                    }
                    
                    input.parentNode.appendChild(errorMsg);
                    input.value = '';
                    
                    // Shake animation for the input
                    gsap.to(input, {
                        x: [-5, 5, -5, 5, 0],
                        duration: 0.4,
                        ease: "power1.out"
                    });
                }
            }
        });
    });
    
    // Auto-format phone numbers with animation
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            const x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
            e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
            
            // Pulse animation on input
            gsap.to(input, {
                scale: 1.02,
                duration: 0.1,
                yoyo: true,
                repeat: 1
            });
        });
    });
    
    // Add ripple effect to buttons
    document.addEventListener('click', function(e) {
        if (e.target.closest('button, [role="button"], .btn')) {
            const button = e.target.closest('button, [role="button"], .btn');
            const ripple = document.createElement('span');
            ripple.className = 'ripple';
            
            // Remove existing ripples
            const existingRipples = button.querySelectorAll('.ripple');
            existingRipples.forEach(r => r.remove());
            
            // Set ripple position and size
            const rect = button.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size/2;
            const y = e.clientY - rect.top - size/2;
            
            ripple.style.width = ripple.style.height = `${size}px`;
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            button.appendChild(ripple);
            
            // Remove ripple after animation
            setTimeout(() => {
                ripple.remove();
            }, 600);
        }
    });
});

// Add GSAP animations to form submissions
document.addEventListener('submit', function(e) {
    const form = e.target;
    if (form.tagName === 'FORM') {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            gsap.to(submitBtn, {
                scale: 0.95,
                duration: 0.1,
                yoyo: true,
                repeat: 1
            });
        }
    }
});